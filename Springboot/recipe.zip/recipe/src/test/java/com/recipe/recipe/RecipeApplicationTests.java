package com.recipe.recipe;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RecipeApplicationTests {

	@Test
	void contextLoads() {
	}

}
